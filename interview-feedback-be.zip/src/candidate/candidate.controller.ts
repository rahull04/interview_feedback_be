import { Controller } from '@nestjs/common';

@Controller('candidate')
export class CandidateController {}
