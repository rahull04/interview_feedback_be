import { Controller } from '@nestjs/common';

@Controller('discipline')
export class DisciplineController {}
