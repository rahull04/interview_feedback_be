export enum UserRoles {
  HR = 'hr',
  USER = 'user',
  SUPERADMIN = 'superadmin',
}
