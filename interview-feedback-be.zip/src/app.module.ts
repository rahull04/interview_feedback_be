import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './user/user.module';
import { InterviewResultsModule } from './interview-results/interview-results.module';
import { DisciplineModule } from './discipline/discipline.module';
import { CandidateModule } from './candidate/candidate.module';

@Module({
  imports: [UserModule, InterviewResultsModule, DisciplineModule, CandidateModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
