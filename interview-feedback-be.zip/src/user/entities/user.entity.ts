import { AuditingEntity } from 'src/core/entities/auditing.entity';
import { UserRoles } from 'src/core/enum/userRoles';
import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class User extends AuditingEntity {

  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column()
  email: string;

  @Column({nullable: true})
  imageUrl: string;

  @Column({
    type: 'enum',
    enum: UserRoles,
    default: UserRoles.USER,
  })
  type: UserRoles;
}
