import { Module } from '@nestjs/common';
import { InterviewResultsController } from './interview-results.controller';
import { InterviewResultsService } from './interview-results.service';

@Module({
  controllers: [InterviewResultsController],
  providers: [InterviewResultsService]
})
export class InterviewResultsModule {}
