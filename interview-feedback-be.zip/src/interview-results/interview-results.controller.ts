import { Controller } from '@nestjs/common';

@Controller('interview-results')
export class InterviewResultsController {}
